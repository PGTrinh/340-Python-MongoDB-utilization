# Author: Philip Trinh
# Created 09/22/2023

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    # constructor
    def __init__(self):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # Definitions of the connection string variables are
        # unique to the individual environment.
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32728
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    # Complete this create method to implement the C in CRUD.
    # Method to create data
    # data input per Pymongo API format
    def create(self, data):
        if data is not None:
            insert_result = self.collection.animals.insert_one(data)  # data should be a dictionary
            if insert_result.acknowledged:  # check insert status (successful insertion)
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    # Create method to implement the R in CRUD.
    # Get data with query
    # All data are return if query is None
    # Default is None
    def read(self, query):
        if query is not None:
            # Use the 'find' method with the provided query
            data = self.collection.find(query, {'_id': 0})

        else:
            data = self.collection.find({}, {'_id': 0})

        return data
