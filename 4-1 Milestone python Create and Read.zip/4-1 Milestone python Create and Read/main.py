#Author: Philip Trinh
#Created 09/22/2023

from AnimalShelter import AnimalShelter
from bson.objectid import ObjectId

animals = AnimalShelter()

#Create record
print(animals.create ({ 
 'age_upon_outcome': "2 years",
 'animal_id': "test_id",
 'animal_type': "Dog",
 'breed': "Alaskan Malamute",
 'color': "Black & White",
 'date_of_birth': "2021-09-23",
 'datetime': "2021-09-23 12:00:00",
 'monthyear': "2021-09-23T12:00:00",
 'name': "Coffee",
 'outcome_subtype': "",
 'outcome_type': "Adoption",
 'sex_upon_outcome': "Male",
 'location_lat': 61.1234,
 'location_long': -149.5678,
 'age_upon_outcome_in_weeks': 104.143055556}))

#query for data created
query = animals.read({'name': "Coffee", 'age_upon_outcome': "2 years"})
for animal in query:
    print(animal) 