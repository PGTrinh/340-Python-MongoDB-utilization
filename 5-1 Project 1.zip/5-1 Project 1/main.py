# Author: Philip Trinh
# Created 09/22/2023

from AnimalShelter import AnimalShelter
from bson.objectid import ObjectId

animals = AnimalShelter()

# Reference: https://www.w3schools.com/python/python_mongodb_insert.asp

# Test for C in CRUD

# Create record, if success = True
print(animals.create({
    'age_upon_outcome': "2 years",
    'animal_id': "test_id",
    'animal_type': "Dog",
    'breed': "Alaskan Malamute",
    'color': "Black & White",
    'date_of_birth': "2021-09-23",
    'datetime': "2021-09-23 12:00:00",
    'monthyear': "2021-09-23T12:00:00",
    'name': "Coffee",
    'outcome_subtype': "",
    'outcome_type': "Adoption",
    'sex_upon_outcome': "Male",
    'location_lat': 61.1234,
    'location_long': -149.5678,
    'age_upon_outcome_in_weeks': 104.143055556}))
# Test for exception when no data is enter
# Return True = saved
# If exception triggered = no data created since it is empty
try:
    empty_data = {}  # An empty dictionary
    result = animals.create(empty_data)
    print("Create Result:", result)
except Exception as e:
    print("Exception Raised:", e)

# Test if it will create data with incorrect format
# If no data create, raise exception
try:
    print(animals.create({
        0: 0}))
except Exception as e:
    print("Incorrect Data format exception:", e)

# Test for R in CRUD

# Query for record created
query = animals.read({'name': "Coffee", 'age_upon_outcome': "2 years"})
for animal in query:
    print(animal)

# Query for record that not exist to see if it return anything
query = animals.read({'Not Exist': 0})
for animal in query:
    print(animal)

# Test for U in CRUD
query = {'name': "Coffee", 'age_upon_outcome': "2 years"}
update_data = {'name': "Dragon", 'age_upon_outcome': "3 years"}
data_updated = animals.update(query, update_data)
print("Data updated:", data_updated)

# Test for D in CRUD
delete_query = {'name': "Dragon", 'age_upon_outcome': "3 years"}
deleted_count = animals.delete(delete_query)
print("Deleted Count:", deleted_count)