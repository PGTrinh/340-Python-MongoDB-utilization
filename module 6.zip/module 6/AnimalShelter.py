# Author: Philip Trinh
# Created 09/22/2023

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    # constructor
    def __init__(self):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # Definitions of the connection string variables are
        # unique to the individual environment.
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32728
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    # Method to implement the C (CREATE) in CRUD
    # Create data if input is not none and not empty
    # data input per Pymongo API format
    def create(self, data):
        if data is not None and len(data) > 0:
            insert_result = self.database.animals.insert_one(data)  # data should be a dictionary
            if insert_result.acknowledged:  # check insert status (successful insertion)
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    # Create method to implement the R in CRUD.
    # Get data with query
    # All data are return based on query
    # Else no query, return empty list
    def read(self, query):
        if query is not None:
            # Use the 'find' method with the provided query
            data = self.collection.find(query, {'_id': 0})
            return data
        else:
            return []

    # Method to implement the U (UPDATE) in CRUD.
    def update(self, query, update_data):
        if update_data is not None and len(update_data) > 0:
            # Use update_one to update a single document matching the query
            data_updated = self.collection.update_one(query, {"$set": update_data})
            # Check if any documents were modified
            if data_updated.modified_count >= 1:
                return data_updated.modified_count
            else:
                raise Exception("No matching document found for the update query")
        else:
            raise Exception("Nothing to update because data parameter is empty or improper format")

     # Method to implement the D (DELETE) in CRUD.
    def delete(self, query):
        if query is not None and len(query) > 0:
        # Use delete_one to delete a single document matching the query
            deleted_data = self.collection.delete_one(query)
            if deleted_data.deleted_count >= 1:
                return deleted_data.deleted_count
        # Check if any documents were deleted
            else:
                raise Exception("No matching document found for the delete query")
        else:
            raise Exception("Nothing to delete because data parameter is empty or improper format")

